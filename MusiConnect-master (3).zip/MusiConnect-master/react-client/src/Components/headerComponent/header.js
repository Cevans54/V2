import React, { Component } from 'react';
import { Link } from 'react-router-dom';
class Header extends Component {
  render() {
    return (
  <html>
      <body>
        <div class="header">
            <img src="../images/Logo.png" alt="Musiconnect Logo"/>
        </div>
      </body>
    </html>
    )
  }
}
export default Header;