# MusiConnect
- The Main Repository for MusiConnect

# What you need to download (most likely already have downloaded)
- download nodejs form nodejs.org
```
sudo npm install -g

sudo npm install -g nodemon
```

# How to run, run each command in seperate terminal windows
```
npm run react-dev

npm run server-dev
```

# How to install chatkit 
```
npm install @pusher/chatkit-client

npm install @pusher/chatkit-server 
```
